# DataMan project
# 09/28/2022
# CTS-285 Dataman
# Brandon Strother
EXIT = 0
RETURN = 3

class menu():
    def main_menu():
        #Creates the menus for the program
        print("-------MENU-------")
        
        print("1) Answer Checker")
        print("2) Memory Bank")
        print("0) Exit") 
        print("-------------------\n")
    def answerChecker_menu():    
        print("-------MENU-------")
        
        print("1) Addition Problem")
        print("2) Subtraction Problem")
        print("3) return to main")
        print("-------------------\n")
    def memoryBank_menu():
        print("-------MENU-------")
        
        print("1) Save Problem")
        print("2) Currently Saved Problems")
        print("3) return to main")
        print("-------------------\n")

# class answer_checker():
#     def addition():
       

def main():
    menu.main_menu()
    choice = int(input("Enter choice: "))
    
    while choice != EXIT:
        
        #Answer checker code
        if choice == 1:
            menu.answerChecker_menu()  
            
            while choice != RETURN:
            
                choice = int(input("Enter choice: "))
                #addition
                if choice == 1:    
                    print("Enter an addition question")
                    print("in this format 1 + 1 = 2")
                    userProblem = input()
                    problemItems = userProblem.split(" ")
                    fnum = int(problemItems[0])
                    operator = (problemItems[1])
                    snum = int(problemItems[2])
                    useranswer = int(problemItems[4])
                    problem = str(fnum) + ' ' + str(operator) + ' ' +\
                    str(snum) + ' ' + "=" + ' ' + str(useranswer)
                    print("Your problem was " + problem)
                    answer = fnum + snum
                    if answer == useranswer:
                        print("correct")
                    else:
                        print("incorrect")
                #subtraction
                elif choice == 2:
                    print("1 - 1 = 2")
    
                elif choice == RETURN:
                    print("return to main menu")
                menu.answerChecker_menu()    
           
       #Memory bank code
        elif choice == 2:    
            
                menu.memoryBank_menu()   
                
                while choice != RETURN:
            
                    choice = int(input("Enter choice: "))
                
                
        menu.main_menu()
        choice = int(input("Enter choice: "))
    
        
    
main()