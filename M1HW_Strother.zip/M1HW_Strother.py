# Creates a menu driven program for math problems
# 08/24/2022
# CTS-285 M1HW1
# Brandon Strother

EXIT = 5

class menu():
    def menu():
        #Creates the menu for the program
        print("-------MENU-------")
        
        print("1) Add")
        print("2) Subtract")
        print("3) Multiply")
        print("4) Divide")
        print("5) Exit") 
        print("-------------------\n")

class calc():
    def add():
        fnum = int(input("enter a number: "))
        snum = int(input("enter a second number: "))
        total = fnum + snum
        print(fnum,"+",snum,"=",total)        
    def subtract():
        fnum = int(input("enter a number: "))
        snum = int(input("enter a second number: "))
        total = fnum - snum
        print(fnum,"-",snum,"=",total)
    def multiply():
        fnum = int(input("enter a number: "))
        snum = int(input("enter a second number: "))
        total = fnum * snum
        print(fnum,"*",snum,"=",total)
    def divide():
        fnum = int(input("enter a number: "))
        snum = int(input("enter a second number: "))
        total = fnum / snum
        print(fnum,"/",snum,"=",total)   

def main():
     
    menu.menu()
    
    choice = int(input("Enter choice: "))
    
    while choice != EXIT:
        
        if choice == 1:
            calc.add()
        
        elif choice == 2:
            calc.subtract()
       
        elif choice == 3:
            calc.multiply()
       
        elif choice == 4:
            calc.divide()
   
        else:
            choice = int(input("Please enter a number from the given choices: "))
        menu.menu()
        choice = int(input("Enter Choice: "))
    
    if choice == EXIT:
        print("Goodbye")
main()